import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.database.mongodb_connection import get_db
from src.analytics.dahi_engine import DAHIEngine
from src.analytics.mape_engine import MAPEEngine
from src.agent.ama_engine import AMAEngine

# ------------------------- PAGE CONFIG -------------------------
st.set_page_config(
    page_title="MaintainIQ",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# ------------------------- HIDE STREAMLIT ELEMENTS -------------------------
hide_streamlit_style = """
    <style>
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
        .stDeployButton {display: none;}
        .stAppToolbar {display: none;}
        .stSidebar {display: none;}
        .stDecoration {display: none;}
    </style>
"""
st.markdown(hide_streamlit_style, unsafe_allow_html=True)

# ------------------------- INIT -------------------------
@st.cache_resource
def init():
    db = get_db()
    return {
        "db": db,
        "dahi": DAHIEngine(),
        "mape": MAPEEngine(),
        "ama": AMAEngine()
    }

engines = init()

# ------------------------- DATA LOAD -------------------------
@st.cache_data(ttl=60)
def load_data(asset_id):
    db = engines["db"]
    health = db.health_reports.find_one({"asset_id": asset_id}, sort=[("timestamp", -1)])
    anomalies = list(db.anomaly_predictions.find({"asset_id": asset_id}, limit=100))
    queue = list(db.recommendations.find().sort("priority_score", -1))
    asset = db.assets.find_one({"_id": asset_id})
    return health, anomalies, queue, asset

assets = list(engines["db"].assets.find())
asset_ids = [a["_id"] for a in assets] if assets else ["COMP_01"]
selected_asset = asset_ids[0]

health, anomalies, queue, asset = load_data(selected_asset)

# ================================================================
# CUSTOM CSS - Modern Clean Design with Proper Spacing
# ================================================================
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    
    * {
        font-family: 'Inter', -apple-system, sans-serif;
    }
    
    .stApp {
        background: #f5f7fa;
    }
    
    /* HEADER */
    .header-container {
        background: #ffffff;
        padding: 1rem 2rem;
        border-radius: 14px;
        margin-bottom: 1.5rem;
        box-shadow: 0 1px 6px rgba(0,0,0,0.04);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    
    .header-left {
        display: flex;
        align-items: center;
        gap: 0.8rem;
    }
    
    .header-icon {
        font-size: 1.8rem;
    }
    
    .header-title {
        font-size: 1.6rem;
        font-weight: 700;
        color: #1a2634;
        letter-spacing: -0.3px;
    }
    
    .header-title span {
        color: #3b82f6;
    }
    
    .header-subtitle {
        font-size: 0.7rem;
        color: #6b7a8a;
        font-weight: 400;
        letter-spacing: 0.3px;
    }
    
    .header-tags {
        display: flex;
        gap: 0.6rem;
        flex-wrap: wrap;
    }
    
    .header-tag {
        background: #f0f4f8;
        padding: 0.2rem 0.8rem;
        border-radius: 20px;
        font-size: 0.6rem;
        color: #3b6b8a;
        font-weight: 500;
        letter-spacing: 0.2px;
    }
    
    /* SECTION HEADERS - PROPER SPACING */
    .section-title {
        font-size: 1rem;
        font-weight: 600;
        color: #1a2634;
        margin-top: 2.2rem;
        margin-bottom: 0.6rem;
        padding-bottom: 0.3rem;
        border-bottom: 2px solid #e8ecf1;
        letter-spacing: -0.2px;
    }
    
    /* METRIC CARDS */
    .metric-card {
        background: #ffffff;
        border-radius: 12px;
        padding: 1rem 0.8rem;
        text-align: center;
        box-shadow: 0 1px 4px rgba(0,0,0,0.04);
        transition: box-shadow 0.2s ease;
    }
    
    .metric-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    }
    
    .metric-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #1a2634;
        line-height: 1.2;
    }
    
    .metric-value.critical-text {
        color: #dc3545;
    }
    
    .metric-value.warning-text {
        color: #f59e0b;
    }
    
    .metric-value.good-text {
        color: #10b981;
    }
    
    .metric-label {
        font-size: 0.6rem;
        color: #6b7a8a;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        margin-top: 0.2rem;
    }
    
    /* SENSOR CARDS */
    .sensor-card {
        background: #ffffff;
        border-radius: 10px;
        padding: 0.6rem 1rem;
        margin: 0.3rem 0;
        box-shadow: 0 1px 4px rgba(0,0,0,0.03);
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: box-shadow 0.2s ease;
    }
    
    .sensor-card:hover {
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    }
    
    .sensor-name {
        font-weight: 500;
        font-size: 0.85rem;
        color: #2d3a4a;
    }
    
    .sensor-right {
        display: flex;
        align-items: center;
        gap: 0.6rem;
    }
    
    .sensor-score {
        font-weight: 700;
        font-size: 1.1rem;
    }
    
    .sensor-score.good {
        color: #10b981;
    }
    
    .sensor-score.warning {
        color: #f59e0b;
    }
    
    .sensor-score.critical {
        color: #dc3545;
    }
    
    .sensor-status-badge {
        font-size: 0.55rem;
        font-weight: 600;
        padding: 0.15rem 0.6rem;
        border-radius: 20px;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .badge-good {
        background: #d1fae5;
        color: #065f46;
    }
    
    .badge-warning {
        background: #fef3c7;
        color: #92400e;
    }
    
    .badge-critical {
        background: #fee2e2;
        color: #991b1b;
    }
    
    /* INFO BOXES */
    .info-box {
        background: #ffffff;
        border-radius: 10px;
        padding: 0.8rem 1.2rem;
        box-shadow: 0 1px 4px rgba(0,0,0,0.04);
        border-left: 3px solid #3b82f6;
        margin: 0.4rem 0;
    }
    
    .info-box.warning-box {
        border-left-color: #dc3545;
        background: #fefaf9;
    }
    
    .info-box.success-box {
        border-left-color: #10b981;
        background: #f9fcfb;
    }
    
    .info-box-label {
        font-size: 0.65rem;
        font-weight: 600;
        color: #6b7a8a;
        text-transform: uppercase;
        letter-spacing: 0.4px;
    }
    
    .info-box-value {
        font-size: 0.95rem;
        font-weight: 600;
        color: #1a2634;
    }
    
    /* DATA FRAME */
    .stDataFrame {
        border-radius: 10px !important;
        overflow: hidden !important;
    }
    
    /* FOOTER */
    .footer {
        text-align: center;
        color: #8a9aa8;
        font-size: 0.65rem;
        margin-top: 2.5rem;
        padding-top: 1rem;
        border-top: 1px solid #e8ecf1;
    }
    
    .footer strong {
        color: #4a5a6a;
    }
    
    .footer-tech {
        color: #3b82f6;
    }
</style>
""", unsafe_allow_html=True)

# ================================================================
# HEADER
# ================================================================
st.markdown(f"""
<div class="header-container">
    <div class="header-left">
        <span class="header-icon">🏭</span>
        <div>
            <div class="header-title">Maintain<span>IQ</span></div>
            <div class="header-subtitle">Explainable Asset Health Intelligence</div>
        </div>
    </div>
    <div class="header-tags">
        <span class="header-tag">DAHI</span>
        <span class="header-tag">MAPE</span>
        <span class="header-tag">EME</span>
        <span class="header-tag">AMA</span>
        <span class="header-tag">LSTM</span>
        <span class="header-tag">MongoDB</span>
    </div>
</div>
""", unsafe_allow_html=True)

# ================================================================
# ROW 1: Asset Overview
# ================================================================
st.markdown('<p class="section-title">📌 Asset Overview</p>', unsafe_allow_html=True)

col1, col2 = st.columns(2)
with col1:
    st.caption("Asset ID")
    st.markdown(f"**{selected_asset}**")
with col2:
    st.caption("Asset Name")
    name = asset.get("name", "Compressor Unit 1") if asset else "Compressor Unit 1"
    st.markdown(f"**{name}**")

# ================================================================
# ROW 2: Key Metrics
# ================================================================
st.markdown('<p class="section-title">📊 Key Metrics</p>', unsafe_allow_html=True)

col1, col2, col3, col4 = st.columns(4)

with col1:
    score = health["health_score"] if health else "—"
    score_val = float(score) if score != "—" else 0
    color_class = "critical-text" if score_val < 40 else "warning-text" if score_val < 70 else "good-text"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value {color_class}">{score}</div>
        <div class="metric-label">DAHI Health Score</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    risk = health["risk_level"].upper() if health else "—"
    color_class = "critical-text" if risk == "CRITICAL" else "warning-text" if risk == "HIGH" else "good-text"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value {color_class}">{risk}</div>
        <div class="metric-label">Risk Level</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    anomaly_count = len(anomalies)
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value">{anomaly_count}</div>
        <div class="metric-label">Anomalies (24h)</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    priority = queue[0]["priority_score"] if queue else 0
    color_class = "critical-text" if priority > 70 else "warning-text" if priority > 40 else "good-text"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value {color_class}">{priority:.1f}</div>
        <div class="metric-label">MAPE Priority</div>
    </div>
    """, unsafe_allow_html=True)

# ================================================================
# ROW 3: Sensor Health + Root Cause
# ================================================================
colL, colR = st.columns([2, 1])

with colL:
    st.markdown('<p class="section-title">🔬 Sensor Health (DAHI)</p>', unsafe_allow_html=True)
    
    if health and "sensor_scores" in health:
        scores = health["sensor_scores"]
        active_sensors = {k: v for k, v in scores.items() if v > 0}
        
        if active_sensors:
            for sensor, score in active_sensors.items():
                if score >= 70:
                    status = "Healthy"
                    badge_class = "badge-good"
                    score_class = "good"
                elif score >= 40:
                    status = "Needs Attention"
                    badge_class = "badge-warning"
                    score_class = "warning"
                else:
                    status = "Critical"
                    badge_class = "badge-critical"
                    score_class = "critical"
                
                st.markdown(f"""
                <div class="sensor-card">
                    <span class="sensor-name">{sensor}</span>
                    <div class="sensor-right">
                        <span class="sensor-score {score_class}">{score:.1f}</span>
                        <span style="font-size:0.7rem;color:#8a9aa8;">/ 100</span>
                        <span class="sensor-status-badge {badge_class}">{status}</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            
            st.markdown('<p style="font-size:0.85rem;font-weight:600;color:#4a5a6a;margin-top:0.8rem;margin-bottom:0.3rem;">📉 Sensor Health Ranking (Lowest to Highest)</p>', unsafe_allow_html=True)
            
            df_sensors = pd.DataFrame([
                {"Sensor": k, "Score": v} for k, v in active_sensors.items()
            ]).sort_values("Score", ascending=True)
            
            fig = px.bar(
                df_sensors,
                x="Score",
                y="Sensor",
                orientation="h",
                range_x=[0, 100],
                color="Score",
                color_continuous_scale=["#dc3545", "#f59e0b", "#10b981"],
                text="Score",
                height=200
            )
            fig.update_layout(
                margin=dict(l=0, r=0, t=5, b=0),
                font=dict(family="Inter", size=11),
                plot_bgcolor="white",
                paper_bgcolor="white",
                showlegend=False,
                xaxis=dict(gridcolor="#f0f2f5", tickfont=dict(size=10)),
                yaxis=dict(gridcolor="#f0f2f5", tickfont=dict(size=11))
            )
            fig.update_traces(
                texttemplate='%{text:.1f}', 
                textposition='outside',
                textfont=dict(size=10)
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.caption("No active sensor data")
    else:
        st.caption("No health data")

with colR:
    st.markdown('<p class="section-title">🔍 Root Cause (EME)</p>', unsafe_allow_html=True)
    
    if health and "sensor_scores" in health:
        scores = health["sensor_scores"]
        active_sensors = {k: v for k, v in scores.items() if v > 0}
        
        if active_sensors:
            sorted_sensors = sorted(active_sensors.items(), key=lambda x: x[1])
            worst_sensor, worst_score = sorted_sensors[0]
            
            st.markdown(f"""
            <div class="info-box warning-box">
                <div class="info-box-label">⚠️ Primary Issue</div>
                <div class="info-box-value">{worst_sensor} → {worst_score:.1f}/100</div>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="info-box success-box">
                <div class="info-box-label">💡 Recommendation</div>
                <div class="info-box-value" style="font-size:0.85rem;">Investigate {worst_sensor} sensor</div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.caption("No active sensors")
    else:
        st.caption("No health data")

# ================================================================
# ROW 4: MAPE Priority – Sensor Focus
# ================================================================
st.markdown('<p class="section-title">📋 Maintenance Priority (MAPE)</p>', unsafe_allow_html=True)

if health and "sensor_scores" in health:
    scores = health["sensor_scores"]
    active_sensors = {k: v for k, v in scores.items() if v > 0}
    
    if active_sensors:
        sorted_sensors = sorted(active_sensors.items(), key=lambda x: x[1])
        
        sensor_priority = []
        for i, (sensor, score) in enumerate(sorted_sensors):
            if score < 40:
                risk = "CRITICAL"
            elif score < 70:
                risk = "HIGH"
            else:
                risk = "LOW"
            
            sensor_priority.append({
                "Rank": i + 1,
                "Sensor": sensor,
                "Score": round(score, 1),
                "Priority Score": round((100 - score) * 1.5, 1),
                "Risk": risk
            })
        
        df_sensor_priority = pd.DataFrame(sensor_priority)
        st.dataframe(
            df_sensor_priority[["Rank", "Sensor", "Score", "Priority Score", "Risk"]],
            use_container_width=True,
            hide_index=True,
            column_config={
                "Sensor": "🔧 Sensor",
                "Score": "📊 Health Score",
                "Priority Score": "⚡ Priority",
                "Risk": "⚠️ Risk"
            }
        )
        
        top_sensor, top_score = sorted_sensors[0]
        st.markdown(f"""
        <div class="info-box warning-box">
            <div class="info-box-label">⚡ Top Priority Action</div>
            <div class="info-box-value">
                Focus on <strong style="color:#dc3545;">{top_sensor}</strong> 
                ({top_score:.1f}/100) – Needs immediate attention
            </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.caption("No active sensors")
else:
    st.caption("No health data available")

# ================================================================
# ROW 5: Anomalies + Agentic Assistant (AMA)
# ================================================================
colA, colB = st.columns(2)

with colA:
    st.markdown('<p class="section-title">⚠️ Anomalies (LSTM)</p>', unsafe_allow_html=True)
    if anomalies:
        df_a = pd.DataFrame([{
            "Time": a["timestamp"].strftime("%Y-%m-%d %H:%M") if hasattr(a["timestamp"], "strftime") else str(a["timestamp"]),
            "Error": round(a.get("reconstruction_error", 0), 4)
        } for a in anomalies[:8]])
        st.dataframe(df_a, use_container_width=True, hide_index=True)
        st.caption(f"{len(anomalies)} anomalies detected")
    else:
        st.caption("✅ No anomalies detected")

with colB:
    st.markdown('<p class="section-title">🤖 Agentic Assistant (AMA)</p>', unsafe_allow_html=True)
    
    # Predefined query options
    query_options = [
        "Which assets need maintenance today?",
        "Show me health status of all compressors",
        "Which assets are at critical risk?",
        "Maintenance history of COMP_01",
        "Sensor readings for COMP_01 in last 24 hours"
    ]
    
    # Dropdown for predefined queries
    selected = st.selectbox("Choose a query:", ["— Select —"] + query_options, label_visibility="collapsed")
    
    if selected != "— Select —":
        with st.spinner("🔍 Analyzing your query..."):
            reply = engines["ama"].process_query(selected)
            st.markdown("---")
            st.markdown(reply)
    
    # Free text input
    st.caption("Or type your own question:")
    free_query = st.text_input("", placeholder="e.g., What is the health status of COMP_01?", key="ama_free_input")
    
    if free_query:
        with st.spinner("🔍 Analyzing your query..."):
            reply = engines["ama"].process_query(free_query)
            st.markdown("---")
            st.markdown(reply)

# ================================================================
# FOOTER
# ================================================================
st.markdown(f"""
<div class="footer">
    <strong>MaintainIQ</strong> · DAHI · MAPE · EME · AMA · 
    <span class="footer-tech">LSTM Autoencoder</span> · 
    <span class="footer-tech">MongoDB Time-Series</span>
</div>
""", unsafe_allow_html=True)