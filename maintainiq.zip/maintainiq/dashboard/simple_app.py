import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.database.mongodb_connection import get_db
from src.analytics.dahi_engine import DAHIEngine
from src.analytics.mape_engine import MAPEEngine
from src.config import ASSET_ID

st.set_page_config(page_title="MaintainIQ", page_icon="🏭", layout="wide")

st.title("🏭 MaintainIQ Dashboard")

@st.cache_data(ttl=60)
def get_data():
    db = get_db()
    dahi = DAHIEngine()
    mape = MAPEEngine()
    
    # Get latest health
    health = dahi.get_latest_health()
    
    # Get priority queue
    queue = mape.get_priority_queue(limit=5)
    
    # Get recent anomalies
    anomalies = list(db.anomaly_predictions.find(
        {"asset_id": ASSET_ID},
        sort=[("timestamp", -1)],
        limit=100
    ))
    
    # Get asset config
    asset = db.assets.find_one({"_id": ASSET_ID})
    
    return health, queue, anomalies, asset

try:
    health, queue, anomalies, asset = get_data()
except Exception as e:
    st.error(f"Error loading data: {e}")
    st.stop()

# Display basic info
col1, col2, col3, col4 = st.columns(4)

with col1:
    if health:
        st.metric("Health Score", f"{health.get('health_score', 'N/A')}")
    else:
        st.metric("Health Score", "No Data")

with col2:
    if health:
        st.metric("Risk Level", health.get('risk_level', 'unknown').upper())
    else:
        st.metric("Risk Level", "N/A")

with col3:
    st.metric("Anomalies (24h)", len(anomalies))

with col4:
    if asset:
        st.metric("Asset", asset.get('name', ASSET_ID))

# Priority Queue
st.subheader("📋 Maintenance Priority Queue")
if queue:
    df = pd.DataFrame([{
        "Rank": i+1,
        "Asset": q['asset_id'],
        "Health": q.get('health_score', 0),
        "Priority": q.get('priority_score', 0)
    } for i, q in enumerate(queue)])
    st.dataframe(df, use_container_width=True)
else:
    st.info("No assets in queue")

# Recent Anomalies
st.subheader("⚠️ Recent Anomalies")
if anomalies:
    df = pd.DataFrame([{
        "Time": a['timestamp'],
        "Error": round(a.get('reconstruction_error', 0), 4)
    } for a in anomalies[:20]])
    st.dataframe(df, use_container_width=True)
else:
    st.info("No anomalies detected")

# Sensor Scores
if health and 'sensor_scores' in health:
    st.subheader("📊 Sensor Health Scores")
    sensor_df = pd.DataFrame([
        {"Sensor": k, "Score": v}
        for k, v in health['sensor_scores'].items()
    ])
    fig = px.bar(
        sensor_df,
        x="Sensor",
        y="Score",
        range_y=[0, 100],
        color="Score",
        color_continuous_scale="RdYlGn"
    )
    st.plotly_chart(fig, use_container_width=True)

st.caption("MaintainIQ - Industrial Asset Health Intelligence")