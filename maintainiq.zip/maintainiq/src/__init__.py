"""
MaintainIQ - Explainable AI Framework for Industrial Asset Health Intelligence
"""
__version__ = "1.0.0"