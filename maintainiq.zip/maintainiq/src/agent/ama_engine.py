import re
import logging
from datetime import datetime, timedelta
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.mongodb_connection import get_db
from config import SUPPORTED_QUERIES

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AMAEngine:
    """Agentic Maintenance Assistant"""

    def __init__(self):
        self.db = get_db()

    def process_query(self, query):
        """Process natural language query and return response"""
        query_lower = query.lower().strip()

        # --------------------------
        # QUERY TYPE DETECTION
        # --------------------------

        # 1. Maintenance Queue
        if "need maintenance" in query_lower or "maintenance today" in query_lower or "priority queue" in query_lower:
            return self._get_maintenance_queue()

        # 2. Compressor Health
        elif "health status" in query_lower and ("compressor" in query_lower or "all" in query_lower):
            return self._get_compressor_health()

        # 3. Critical Risk
        elif "critical risk" in query_lower or "critical assets" in query_lower:
            return self._get_critical_assets()

        # 4. Maintenance History
        elif "maintenance history" in query_lower:
            match = re.search(r'asset\s+(\w+|\d+)', query_lower)
            if match:
                return self._get_maintenance_history(match.group(1))
            return self._error_response("Please specify an asset ID. Example: 'Maintenance history of COMP_01'")

        # 5. Sensor Readings (Last 24 hours)
        elif "sensor readings" in query_lower and "last 24" in query_lower:
            match = re.search(r'asset\s+(\w+|\d+)', query_lower)
            if match:
                return self._get_sensor_readings(match.group(1), hours=24)
            return self._error_response("Please specify an asset ID. Example: 'Sensor readings for COMP_01 in last 24 hours'")

        # 6. Sensor Readings (Custom time)
        elif "sensor readings" in query_lower:
            match = re.search(r'asset\s+(\w+|\d+)', query_lower)
            if match:
                return self._get_sensor_readings(match.group(1), hours=24)
            return self._error_response("Please specify an asset ID. Example: 'Sensor readings for COMP_01'")

        # 7. Health Score (Single Asset)
        elif "health" in query_lower and "score" in query_lower:
            match = re.search(r'asset\s+(\w+|\d+)', query_lower)
            if match:
                return self._get_asset_health(match.group(1))
            return self._get_asset_health("COMP_01")

        # 8. General / Unknown
        else:
            return self._error_response(f"Query not supported.\n\nSupported queries:\n" + "\n".join([f"• {q}" for q in SUPPORTED_QUERIES]))

    # ========================================
    # RESPONSE FUNCTIONS
    # ========================================

    def _get_maintenance_queue(self, limit=10):
        """Get the maintenance priority queue"""
        recommendations = list(self.db.recommendations.find().sort("priority_score", -1).limit(limit))

        if not recommendations:
            return "✅ No assets in the maintenance queue. All assets are operating within normal parameters."

        result = "### 🚨 Maintenance Priority Queue\n\n"
        for rec in recommendations[:limit]:
            rank = rec.get('rank', 'N/A')
            asset = rec.get('asset_id', 'Unknown')
            priority = rec.get('priority_score', 0)
            health = rec.get('health_score', 0)
            risk = rec.get('risk_level', 'unknown').upper()

            result += f"**#{rank}** – `{asset}`\n"
            result += f"  • Priority Score: **{priority:.1f}**\n"
            result += f"  • Health Score: {health:.1f} / 100\n"
            result += f"  • Risk Level: **{risk}**\n\n"

        return result

    def _get_compressor_health(self):
        """Get health status of all compressors"""
        assets = list(self.db.assets.find({"type": "compressor"}))

        if not assets:
            return "ℹ️ No compressors found in the system."

        result = "### 📊 Compressor Health Status\n\n"
        for asset in assets:
            asset_id = asset["_id"]
            name = asset.get("name", asset_id)

            health = self.db.health_reports.find_one(
                {"asset_id": asset_id},
                sort=[("timestamp", -1)]
            )

            if health:
                score = health.get('health_score', 0)
                risk = health.get('risk_level', 'unknown').upper()
                result += f"**{name}** (`{asset_id}`)\n"
                result += f"  • Health Score: **{score:.1f}** / 100\n"
                result += f"  • Risk Level: **{risk}**\n\n"
            else:
                result += f"**{name}** (`{asset_id}`)\n"
                result += f"  • No health data available\n\n"

        return result

    def _get_critical_assets(self):
        """Get all assets at critical risk"""
        health_reports = list(self.db.health_reports.find(
            {"risk_level": "critical"},
            sort=[("timestamp", -1)]
        ))

        if not health_reports:
            return "✅ No assets are currently at critical risk."

        result = "### ⚠️ Critical Risk Assets\n\n"
        for health in health_reports:
            asset_id = health["asset_id"]
            asset = self.db.assets.find_one({"_id": asset_id})
            name = asset.get("name", asset_id) if asset else asset_id
            score = health.get('health_score', 0)
            timestamp = health['timestamp'].strftime("%Y-%m-%d %H:%M") if hasattr(health['timestamp'], 'strftime') else str(health['timestamp'])

            result += f"**{name}** (`{asset_id}`)\n"
            result += f"  • Health Score: **{score:.1f}** / 100\n"
            result += f"  • Detected: {timestamp}\n\n"

        return result

    def _get_maintenance_history(self, asset_id):
        """Get maintenance history for a specific asset"""
        asset = self.db.assets.find_one({"_id": asset_id})

        if not asset:
            return f"❌ Asset `{asset_id}` not found. Please check the asset ID and try again."

        history = asset.get("maintenance_history", [])

        if not history:
            return f"ℹ️ No maintenance history found for `{asset_id}`."

        name = asset.get("name", asset_id)
        result = f"### 🛠️ Maintenance History: {name} (`{asset_id}`)\n\n"

        for entry in history:
            date = entry.get('date', 'Unknown')
            if isinstance(date, datetime):
                date = date.strftime("%Y-%m-%d")
            entry_type = entry.get('type', 'Unknown').capitalize()
            cost = entry.get('cost', 'N/A')

            result += f"**{entry_type}** on {date}\n"
            result += f"  • Cost: ${cost}\n\n"

        return result

    def _get_sensor_readings(self, asset_id, hours=24):
        """Get sensor readings for a specific asset"""
        cutoff = datetime.now() - timedelta(hours=hours)

        # Check if asset exists
        asset = self.db.assets.find_one({"_id": asset_id})
        if not asset:
            return f"❌ Asset `{asset_id}` not found."

        readings = list(self.db.sensor_readings.find(
            {"asset_id": asset_id, "timestamp": {"$gte": cutoff}}
        ).sort("timestamp", 1).limit(20))

        if not readings:
            return f"ℹ️ No readings found for `{asset_id}` in the last {hours} hours."

        name = asset.get("name", asset_id)
        result = f"### 📈 Sensor Readings: {name} (`{asset_id}`)\n"
        result += f"*Last {hours} hours (showing latest 20 readings)*\n\n"

        for reading in readings:
            ts = reading['timestamp'].strftime("%Y-%m-%d %H:%M") if hasattr(reading['timestamp'], 'strftime') else str(reading['timestamp'])
            sensors = [f"{k}: {v}" for k, v in reading.items()
                       if k not in ['_id', 'asset_id', 'timestamp']][:5]

            result += f"**{ts}**\n"
            result += f"  • " + " | ".join(sensors) + "\n"

        return result

    def _get_asset_health(self, asset_id="COMP_01"):
        """Get health report for a specific asset"""
        asset = self.db.assets.find_one({"_id": asset_id})
        if not asset:
            return f"❌ Asset `{asset_id}` not found."

        health = self.db.health_reports.find_one(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)]
        )

        if not health:
            return f"ℹ️ No health data available for `{asset_id}`."

        name = asset.get("name", asset_id)
        score = health.get('health_score', 0)
        risk = health.get('risk_level', 'unknown').upper()
        sensors = health.get('sensor_scores', {})

        result = f"### 🏥 Health Report: {name} (`{asset_id}`)\n\n"
        result += f"**Health Score:** {score:.1f} / 100\n"
        result += f"**Risk Level:** **{risk}**\n\n"

        if sensors:
            result += "**Sensor Breakdown:**\n"
            for sensor, s_score in sensors.items():
                if s_score >= 70:
                    status = "✅ Healthy"
                elif s_score >= 40:
                    status = "⚠️ Needs Attention"
                else:
                    status = "🔴 Critical"
                result += f"  • {sensor}: {s_score:.1f} / 100 – {status}\n"

        return result

    def _error_response(self, message):
        """Return a user-friendly error message"""
        return f"❌ {message}"
