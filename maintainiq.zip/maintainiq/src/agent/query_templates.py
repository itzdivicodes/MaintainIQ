SUPPORTED_QUERIES = [
    "Which assets need maintenance today?",
    "Show me health status of all compressors",
    "Which assets are at critical risk?",
    "What is the maintenance history of Asset X?",
    "Show me sensor readings for Asset Y in last 24 hours"
]

def get_query_response(query_type, **kwargs):
    """Template for query responses"""
    responses = {
        "maintenance_queue": "Priority queue of assets needing attention",
        "compressor_health": "Health status of all compressors",
        "critical_assets": "Assets at critical risk",
        "maintenance_history": f"Maintenance history for {kwargs.get('asset_id', 'Asset X')}",
        "sensor_readings": f"Sensor readings for {kwargs.get('asset_id', 'Asset Y')} in last 24 hours"
    }
    return responses.get(query_type, "Query not recognized")