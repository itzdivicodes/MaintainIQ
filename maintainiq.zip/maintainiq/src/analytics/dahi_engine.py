import logging
from datetime import datetime
from ..database.mongodb_connection import get_db
from ..config import ASSET_ID, NORMAL_RANGES, DAHI_WEIGHTS, SENSOR_FEATURES

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DAHIEngine:
    """Dynamic Asset Health Index Engine"""
    
    def __init__(self):
        self.db = get_db()
        self.normal_ranges = NORMAL_RANGES
        self.weights = DAHI_WEIGHTS
        self.sensor_features = SENSOR_FEATURES
    
    def compute_sensor_score(self, sensor_name, value):
        """Compute individual sensor health score (0-100)"""
        if sensor_name not in self.normal_ranges:
            return 50
        
        ranges = self.normal_ranges[sensor_name]
        normal_mid = ranges['mid']
        allowed_range = ranges['range']
        
        deviation = abs(value - normal_mid)
        score = 100 * (1 - min(deviation / allowed_range, 1))
        return round(min(max(score, 0), 100), 2)
    
    def compute_dahi_score(self, sensor_data):
        """Compute overall DAHI score"""
        total_score = 0
        total_weight = 0
        
        for sensor, value in sensor_data.items():
            if sensor in self.weights:
                score = self.compute_sensor_score(sensor, value)
                weight = self.weights[sensor]
                total_score += score * weight
                total_weight += weight
        
        if total_weight == 0:
            return 50.0
        return round(total_score / total_weight, 2)
    
    def compute_health_report(self, asset_id=ASSET_ID):
        """Compute health report for an asset"""
        
        # Get latest sensor readings
        pipeline = [
            {"$match": {"asset_id": asset_id}},
            {"$sort": {"timestamp": -1}},
            {"$limit": 1}
        ]
        
        result = list(self.db.sensor_readings.aggregate(pipeline))
        
        if not result:
            logger.warning(f"No sensor data found for {asset_id}")
            return None
        
        sensor_data = result[0]
        timestamp = sensor_data.pop('timestamp')
        asset_id_val = sensor_data.pop('asset_id')
        
        # Extract only analog sensor features
        analog_data = {}
        for sensor in self.sensor_features:
            if sensor in sensor_data:
                analog_data[sensor] = sensor_data[sensor]
        
        if not analog_data:
            logger.warning(f"No analog sensor data found for {asset_id}")
            return None
        
        # Compute DAHI score
        dahi_score = self.compute_dahi_score(analog_data)
        
        # Compute individual sensor scores
        sensor_scores = {}
        for sensor, value in analog_data.items():
            if sensor in self.weights:
                sensor_scores[sensor] = self.compute_sensor_score(sensor, value)
        
        # Determine risk level
        if dahi_score >= 85:
            risk_level = "low"
        elif dahi_score >= 70:
            risk_level = "medium"
        elif dahi_score >= 40:
            risk_level = "high"
        else:
            risk_level = "critical"
        
        health_report = {
            "asset_id": asset_id,
            "timestamp": timestamp,
            "health_score": dahi_score,
            "sensor_scores": sensor_scores,
            "risk_level": risk_level,
            "raw_data": analog_data
        }
        
        # Save to MongoDB
        self.db.health_reports.insert_one(health_report)
        logger.info(f"✅ Health report generated for {asset_id}: Score={dahi_score}, Risk={risk_level}")
        
        return health_report
    
    def get_latest_health(self, asset_id=ASSET_ID):
        """Get latest health report"""
        return self.db.health_reports.find_one(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)]
        )
    
    def get_health_history(self, asset_id=ASSET_ID, limit=100):
        """Get health history"""
        return list(self.db.health_reports.find(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)],
            limit=limit
        ))