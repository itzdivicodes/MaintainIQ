import logging
from ..database.mongodb_connection import get_db

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DecisionEngine:
    """Maintenance Decision Engine"""
    
    def __init__(self):
        self.db = get_db()
    
    def make_decision(self, asset_id):
        """Make maintenance decision for an asset"""
        
        # Get degradation stage
        degradation = self.db.degradation_stages.find_one(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)]
        )
        
        if not degradation:
            return {
                "asset_id": asset_id,
                "decision": "Unknown",
                "reason": "No degradation data available",
                "confidence": 0
            }
        
        # Get health report
        health = self.db.health_reports.find_one(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)]
        )
        
        # Get priority
        priority = self.db.recommendations.find_one(
            {"asset_id": asset_id},
            sort=[("priority_score", -1)]
        )
        
        # Decision logic based on stage
        stage = degradation.get("stage", 0)
        trend = degradation.get("trend", "stable")
        health_score = degradation.get("health_score", 100)
        
        if stage == 0:
            decision = "Continue Operation"
            confidence = 90
        elif stage == 1:
            decision = "Increase Monitoring"
            confidence = 75
        elif stage == 2:
            decision = "Schedule Inspection"
            confidence = 80
        elif stage == 3:
            decision = "Preventive Maintenance"
            confidence = 85
        elif stage == 4:
            decision = "Immediate Shutdown"
            confidence = 95
        else:
            decision = "Review Required"
            confidence = 50
        
        # Adjust for trend
        if trend == "worsening" and stage >= 2:
            decision = "Immediate Action Recommended"
            confidence = min(confidence + 10, 100)
        
        return {
            "asset_id": asset_id,
            "decision": decision,
            "confidence": confidence,
            "health_score": health_score,
            "stage": degradation.get("stage_name", "Unknown"),
            "trend": trend,
            "priority_score": priority.get("priority_score", 0) if priority else 0,
            "risk_level": health.get("risk_level", "unknown") if health else "unknown",
            "recommendation": f"Action: {decision}",
            "timestamp": degradation.get("timestamp")
        }