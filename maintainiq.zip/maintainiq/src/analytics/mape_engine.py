import logging
from datetime import datetime
from ..database.mongodb_connection import get_db
from ..config import MAPE_WEIGHTS, RISK_LEVELS, CRITICALITY_LEVELS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MAPEEngine:
    """Maintenance Action Prioritization Engine"""
    
    def __init__(self):
        self.db = get_db()
        self.weights = MAPE_WEIGHTS
    
    def compute_priority(self, asset_id):
        """Compute maintenance priority score"""
        
        health = self.db.health_reports.find_one(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)]
        )
        
        if not health:
            return None
        
        asset = self.db.assets.find_one({"_id": asset_id})
        if not asset:
            return None
        
        health_score = health.get("health_score", 100)
        health_urgency = 100 - health_score
        
        risk_level = health.get("risk_level", "low")
        risk_value = RISK_LEVELS.get(risk_level, 1)
        
        criticality = asset.get("criticality", "medium")
        criticality_value = CRITICALITY_LEVELS.get(criticality, 2)
        
        last_maintenance = None
        if "maintenance_history" in asset and asset["maintenance_history"]:
            last_maintenance = asset["maintenance_history"][-1]["date"]
        
        if last_maintenance:
            if isinstance(last_maintenance, str):
                last_maintenance = datetime.fromisoformat(last_maintenance.replace('Z', '+00:00'))
            days_since = (datetime.now() - last_maintenance).days
            maintenance_factor = min(days_since / 30, 1.0)
        else:
            maintenance_factor = 1.0
        
        priority = (
            self.weights["alpha"] * health_urgency +
            self.weights["beta"] * (risk_value / 4 * 100) +
            self.weights["gamma"] * (criticality_value / 3 * 100) +
            self.weights["delta"] * (maintenance_factor * 100)
        )
        
        priority = min(max(priority, 0), 100)
        
        return {
            "asset_id": asset_id,
            "health_score": health_score,
            "health_urgency": health_urgency,
            "risk_level": risk_level,
            "risk_value": risk_value,
            "criticality": criticality,
            "criticality_value": criticality_value,
            "maintenance_factor": maintenance_factor,
            "priority_score": round(priority, 2),
            "timestamp": datetime.now()
        }
    
    def get_priority_queue(self, limit=10):
        """Get ranked maintenance priority queue"""
        assets = self.db.assets.find()
        priorities = []
        
        for asset in assets:
            priority = self.compute_priority(asset["_id"])
            if priority:
                priorities.append(priority)
        
        priorities.sort(key=lambda x: x["priority_score"], reverse=True)
        
        self.db.recommendations.delete_many({})
        for i, item in enumerate(priorities[:limit]):
            item["rank"] = i + 1
            self.db.recommendations.insert_one(item)
        
        return priorities[:limit]