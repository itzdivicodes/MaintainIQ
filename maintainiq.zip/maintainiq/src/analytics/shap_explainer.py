import numpy as np
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SHAPExplainer:
    """SHAP explainer - disabled due to Windows policy"""

    def __init__(self, model, X_train, feature_names):
        logger.warning("⚠️ SHAP is disabled. Using fallback mode.")

    def explain(self, X_sample):
        return {
            "shap_values": np.array([]),
            "feature_importance": np.array([]),
            "top_features": [],
            "message": "SHAP explanation is disabled."
        }

    def get_explanation_text(self, explanation):
        return "SHAP explainer is currently disabled."