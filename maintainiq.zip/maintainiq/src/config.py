import os
from dotenv import load_dotenv

load_dotenv()

# Database
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "maintainiq")

# Data
DATASET_PATH = os.getenv("DATASET_PATH", "data/MetroPT-3.csv")

# Model
SEQUENCE_LENGTH = 60
BATCH_SIZE = 64
EPOCHS = 10
LEARNING_RATE = 0.001
EARLY_STOPPING_PATIENCE = 10
LATENT_DIM = 16
ANOMALY_THRESHOLD_PERCENTILE = 95

# Asset Configuration
ASSET_ID = "COMP_01"

# Sensor Features - MATCH YOUR ACTUAL DATA EXACTLY
SENSOR_FEATURES = ['TP2', 'Motor_current', 'Oil_temperature', 'DV_pressure', 
                   'Reservoirs', 'TP3', 'H1']

# Sensor Normal Ranges (from domain knowledge)
NORMAL_RANGES = {
    'TP2': {'min': 7.0, 'max': 9.0, 'mid': 8.0, 'range': 2.0},
    'Motor_current': {'min': 3.5, 'max': 4.5, 'mid': 4.0, 'range': 1.5},
    'Oil_temperature': {'min': 60, 'max': 85, 'mid': 72, 'range': 25},
    'DV_pressure': {'min': 0.0, 'max': 2.0, 'mid': 0.2, 'range': 2.0},
    'Reservoirs': {'min': 8.0, 'max': 9.5, 'mid': 8.8, 'range': 1.5},
    'TP3': {'min': 8.0, 'max': 9.5, 'mid': 8.8, 'range': 1.5},
    'H1': {'min': 0.0, 'max': 8.0, 'mid': 4.0, 'range': 8.0}
}

# DAHI Weights
DAHI_WEIGHTS = {
    'TP2': 0.25,
    'Motor_current': 0.20,
    'Oil_temperature': 0.20,
    'DV_pressure': 0.15,
    'Reservoirs': 0.10,
    'TP3': 0.05,
    'H1': 0.05
}

# MAPE Weights
MAPE_WEIGHTS = {
    'alpha': 0.40,
    'beta': 0.25,
    'gamma': 0.20,
    'delta': 0.15
}

# Risk Level Mapping
RISK_LEVELS = {
    'low': 1,
    'medium': 2,
    'high': 3,
    'critical': 4
}

# Criticality Mapping
CRITICALITY_LEVELS = {
    'low': 1,
    'medium': 2,
    'high': 3
}

# Supported Queries for AMA
SUPPORTED_QUERIES = [
    "Which assets need maintenance today?",
    "Show me health status of all compressors",
    "Which assets are at critical risk?",
    "What is the maintenance history of Asset X?",
    "Show me sensor readings for Asset Y in last 24 hours"
]