import numpy as np
import logging
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.mongodb_connection import get_db

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ProgressiveDegradation:
    """
    Progressive degradation intelligence
    Stages: Healthy → Minor → Moderate → High → Critical
    """
    
    STAGES = {
        0: {"name": "Healthy", "color": "green", "action": "Continue Operation"},
        1: {"name": "Minor Degradation", "color": "#90EE90", "action": "Increase Monitoring"},
        2: {"name": "Moderate Degradation", "color": "yellow", "action": "Schedule Inspection"},
        3: {"name": "High Degradation", "color": "orange", "action": "Preventive Maintenance"},
        4: {"name": "Critical", "color": "red", "action": "Immediate Shutdown"}
    }
    
    def __init__(self):
        self.db = get_db()
        self.thresholds = {
            0: (0, 20),
            1: (20, 40),
            2: (40, 60),
            3: (60, 80),
            4: (80, 100)
        }
    
    def get_stage(self, degradation_score):
        """Get degradation stage from score (0-100)"""
        for stage, (low, high) in self.thresholds.items():
            if low <= degradation_score < high:
                return stage
        return 4
    
    def get_stage_info(self, stage):
        """Get stage information"""
        return self.STAGES.get(stage, self.STAGES[4])
    
    def compute_degradation_score(self, anomaly_scores, health_score):
        """Compute degradation score from anomaly scores and health score"""
        anomaly_ratio = np.mean(anomaly_scores) if len(anomaly_scores) > 0 else 0
        degradation = (1 - health_score / 100) * 50 + anomaly_ratio * 50
        return min(max(degradation, 0), 100)
    
    def get_trend(self, degradation_history, window=10):
        """Get degradation trend"""
        if len(degradation_history) < window:
            return "stable"
        
        recent = degradation_history[-window:]
        slope = np.polyfit(range(len(recent)), recent, 1)[0]
        
        if slope > 0.5:
            return "worsening"
        elif slope < -0.5:
            return "improving"
        return "stable"
    
    def analyze_asset(self, asset_id):
        """Analyze degradation for an asset"""
        
        health = self.db.health_reports.find_one(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)]
        )
        
        if not health:
            return None
        
        anomalies = self.db.anomaly_predictions.find(
            {"asset_id": asset_id},
            sort=[("timestamp", -1)],
            limit=100
        )
        
        anomaly_list = [a.get('reconstruction_error', 0) for a in anomalies]
        anomaly_scores = np.array(anomaly_list) if anomaly_list else np.array([0])
        
        degradation_score = self.compute_degradation_score(
            anomaly_scores, health['health_score']
        )
        
        stage = self.get_stage(degradation_score)
        stage_info = self.get_stage_info(stage)
        
        trend = self.get_trend(anomaly_list[-20:] if len(anomaly_list) >= 20 else anomaly_list)
        
        result = {
            "asset_id": asset_id,
            "timestamp": health['timestamp'],
            "health_score": health['health_score'],
            "degradation_score": round(degradation_score, 2),
            "stage": stage,
            "stage_name": stage_info['name'],
            "action": stage_info['action'],
            "trend": trend,
            "anomaly_count": len(anomaly_list)
        }
        
        self.db.degradation_stages.insert_one(result)
        
        return result