import tensorflow as tf
from tensorflow.keras import layers, Model
import numpy as np
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LSTMAutoencoder:
    """
    LSTM Autoencoder for unsupervised anomaly detection
    """
    
    def __init__(self, n_features, sequence_length=60, latent_dim=16):
        self.n_features = n_features
        self.sequence_length = sequence_length
        self.latent_dim = latent_dim
        self.model = None
        self.encoder = None
        self.decoder = None
        self._build_model()
    
    def _build_model(self):
        """Build the LSTM Autoencoder architecture"""
        
        # Encoder
        inputs = tf.keras.Input(shape=(self.sequence_length, self.n_features))
        x = layers.LSTM(64, return_sequences=True)(inputs)
        x = layers.LSTM(32, return_sequences=False)(x)
        encoded = layers.Dense(self.latent_dim, activation='relu')(x)
        
        # Decoder
        x = layers.RepeatVector(self.sequence_length)(encoded)
        x = layers.LSTM(32, return_sequences=True)(x)
        x = layers.LSTM(64, return_sequences=True)(x)
        decoded = layers.TimeDistributed(layers.Dense(self.n_features))(x)
        
        self.model = Model(inputs, decoded)
        self.model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                          loss='mse')
        
        self.encoder = Model(inputs, encoded)
        
        logger.info("✅ LSTM Autoencoder built")
    
    def train(self, X_train, X_val, epochs=200, batch_size=64, patience=10):
        """Train the autoencoder"""
        
        callbacks = [
            tf.keras.callbacks.EarlyStopping(
                monitor='val_loss',
                patience=patience,
                restore_best_weights=True
            ),
            tf.keras.callbacks.ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.5,
                patience=5,
                min_lr=1e-6
            )
        ]
        
        history = self.model.fit(
            X_train, X_train,
            validation_data=(X_val, X_val),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=1
        )
        
        logger.info(f"✅ Training completed. Final loss: {history.history['loss'][-1]:.4f}")
        return history
    
    def predict(self, X):
        """Reconstruct input and compute reconstruction error"""
        reconstructed = self.model.predict(X, verbose=0)
        mse = np.mean(np.square(X - reconstructed), axis=(1, 2))
        return mse, reconstructed
    
    def get_anomaly_threshold(self, X_train, percentile=95):
        """Compute anomaly threshold from training data"""
        mse, _ = self.predict(X_train)
        threshold = np.percentile(mse, percentile)
        logger.info(f"✅ Anomaly threshold (95th percentile): {threshold:.4f}")
        return threshold
    
    def detect_anomalies(self, X, threshold):
        """Detect anomalies based on reconstruction error"""
        mse, reconstructed = self.predict(X)
        anomalies = mse > threshold
        return anomalies, mse, reconstructed
    
    def save(self, path="models/saved/"):
        """Save model to disk"""
        os.makedirs(path, exist_ok=True)
        self.model.save(f"{path}lstm_autoencoder.keras")
        logger.info(f"✅ Model saved to {path}")
    
    def load(self, path="models/saved/"):
        """Load model from disk"""
        self.model = tf.keras.models.load_model(f"{path}lstm_autoencoder.keras")
        logger.info(f"✅ Model loaded from {path}")