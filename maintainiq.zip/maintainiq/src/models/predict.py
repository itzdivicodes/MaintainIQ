import numpy as np
import pandas as pd
import joblib
import logging
import sys
import os
import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.mongodb_connection import get_db
from preprocessing.feature_engineering import create_sequences
from config import SENSOR_FEATURES, ASSET_ID
from models.lstm_autoencoder import LSTMAutoencoder

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_model_artifacts():
    """Load trained model and artifacts"""
    features = joblib.load("models/saved/features.pkl")
    n_features = len(features)
    model = LSTMAutoencoder(n_features)
    model.load()
    scaler = joblib.load("models/saved/scaler.pkl")
    threshold = joblib.load("models/saved/threshold.pkl")
    return model, scaler, features, threshold

def predict_anomalies(asset_id=ASSET_ID, hours_back=24):
    """Predict anomalies for an asset using recent data"""
    
    db = get_db()
    model, scaler, features, threshold = load_model_artifacts()
    
    # Get the latest timestamp in the database
    latest_record = db.sensor_readings.find_one(
        {"asset_id": asset_id},
        sort=[("timestamp", -1)]
    )
    
    if not latest_record:
        logger.warning(f"No data found for {asset_id}")
        return None
    
    latest_time = latest_record['timestamp']
    cutoff = latest_time - datetime.timedelta(hours=hours_back)
    
    logger.info(f"📊 Using data from {cutoff} to {latest_time}")
    
    cursor = db.sensor_readings.find({
        "asset_id": asset_id,
        "timestamp": {"$gte": cutoff}
    }).sort("timestamp", 1)
    
    df = pd.DataFrame(list(cursor))
    
    if df.empty:
        logger.warning(f"No data found for {asset_id} in the specified range")
        return None
    
    logger.info(f"📊 Found {len(df)} records")
    
    data = df[SENSOR_FEATURES].values
    scaled = scaler.transform(data)
    
    sequences = create_sequences(scaled, 60)
    
    if len(sequences) == 0:
        logger.warning("Not enough data for prediction")
        return None
    
    anomalies, mse, _ = model.detect_anomalies(sequences, threshold)
    
    results = []
    for i, (is_anomaly, error) in enumerate(zip(anomalies, mse)):
        idx = i + 60
        if idx < len(df):
            results.append({
                "timestamp": df.iloc[idx]['timestamp'],
                "reconstruction_error": float(error),
                "is_anomaly": bool(is_anomaly),
                "asset_id": asset_id
            })
    
    db.anomaly_predictions.delete_many({"asset_id": asset_id})
    if results:
        db.anomaly_predictions.insert_many(results)
    
    logger.info(f"✅ Anomaly detection completed. Found {sum(anomalies)} anomalies out of {len(results)} records")
    
    return results

if __name__ == "__main__":
    predict_anomalies()