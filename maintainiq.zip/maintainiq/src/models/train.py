import numpy as np
import pandas as pd
import logging
import os
import sys
import joblib
from sklearn.preprocessing import StandardScaler

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.mongodb_connection import get_db
from preprocessing.feature_engineering import select_features, create_sequences
from preprocessing.data_splitter import temporal_split
from models.lstm_autoencoder import LSTMAutoencoder
from config import SEQUENCE_LENGTH, BATCH_SIZE, EPOCHS, SENSOR_FEATURES

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def prepare_training_data(df):
    """Prepare data for training"""
    
    df_selected, features = select_features(df, SENSOR_FEATURES)
    train_df, test_df = temporal_split(df_selected, train_ratio=0.8)
    
    scaler = StandardScaler()
    train_scaled = scaler.fit_transform(train_df[SENSOR_FEATURES])
    test_scaled = scaler.transform(test_df[SENSOR_FEATURES])
    
    X_train = create_sequences(train_scaled, SEQUENCE_LENGTH)
    X_test = create_sequences(test_scaled, SEQUENCE_LENGTH)
    
    split_idx = int(0.8 * len(X_train))
    X_train_final = X_train[:split_idx]
    X_val = X_train[split_idx:]
    
    logger.info(f"Training sequences: {len(X_train_final)}")
    logger.info(f"Validation sequences: {len(X_val)}")
    logger.info(f"Test sequences: {len(X_test)}")
    
    return X_train_final, X_val, X_test, scaler, features

def train_model():
    """Main training function"""
    
    db = get_db()
    cursor = db.sensor_readings.find({})
    df = pd.DataFrame(list(cursor))
    
    if df.empty:
        logger.error("No data found in MongoDB. Run import_data.py first.")
        return None
    
    X_train, X_val, X_test, scaler, features = prepare_training_data(df)
    n_features = len(features)
    
    model = LSTMAutoencoder(n_features)
    history = model.train(X_train, X_val, epochs=EPOCHS, batch_size=BATCH_SIZE)
    
    threshold = model.get_anomaly_threshold(X_train, percentile=95)
    
    model.save()
    
    os.makedirs("models/saved/", exist_ok=True)
    joblib.dump(scaler, "models/saved/scaler.pkl")
    joblib.dump(features, "models/saved/features.pkl")
    joblib.dump(threshold, "models/saved/threshold.pkl")
    
    logger.info("🎉 Model training completed!")
    return model, history, threshold

if __name__ == "__main__":
    train_model()