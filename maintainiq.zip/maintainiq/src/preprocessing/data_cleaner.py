import pandas as pd
import numpy as np
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def clean_data(df):
    """Clean the dataset"""
    logger.info("Cleaning data...")
    
    # Remove duplicates
    df = df.drop_duplicates(subset=['timestamp'])
    
    # Handle missing values
    df = df.fillna(method='ffill')
    df = df.fillna(method='bfill')
    
    # Remove outliers using IQR
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 3 * IQR
        upper_bound = Q3 + 3 * IQR
        df[col] = df[col].clip(lower_bound, upper_bound)
    
    logger.info(f"Data cleaned. {len(df)} records remaining")
    return df