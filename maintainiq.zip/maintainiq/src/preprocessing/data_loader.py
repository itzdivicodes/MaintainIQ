import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_metropt_data(file_path):
    """Load MetroPT-3 dataset from CSV"""
    logger.info(f"Loading dataset from: {file_path}")
    
    columns = [
        'timestamp', 'TP2', 'TP3', 'H1', 'DV_pressure', 'Reservoirs',
        'Motor_current', 'Oil_temperature', 'COMP', 'DV_electric',
        'TOWERS', 'MPG', 'LPS', 'Pressure_switch', 'Oil_level',
        'Caudal_impulses'
    ]
    
    df = pd.read_csv(file_path, header=None, names=columns, parse_dates=['timestamp'])
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    logger.info(f"Loaded {len(df)} records from {df['timestamp'].min()} to {df['timestamp'].max()}")
    return df