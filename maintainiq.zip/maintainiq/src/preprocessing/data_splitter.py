import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def temporal_split(df, train_ratio=0.8, buffer_hours=2):
    """Split data temporally (80/20) with buffer"""
    
    # Sort by timestamp
    df = df.sort_values('timestamp')
    
    # Calculate split index
    split_idx = int(len(df) * train_ratio)
    
    # Find split time
    split_time = df.iloc[split_idx]['timestamp']
    
    # Add buffer
    buffer = pd.Timedelta(hours=buffer_hours)
    split_time_buffer = split_time - buffer
    
    # Split data
    train_df = df[df['timestamp'] < split_time_buffer].copy()
    test_df = df[df['timestamp'] >= split_time].copy()
    
    logger.info(f"Training: {len(train_df)} records")
    logger.info(f"Testing: {len(test_df)} records")
    logger.info(f"Split time: {split_time}")
    
    return train_df, test_df