import pandas as pd
import numpy as np
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def select_features(df, feature_cols=None):
    """Select relevant features for modeling"""
    if feature_cols is None:
        feature_cols = ['TP2', 'Motor_current', 'Oil_temperature', 'DV_pressure', 
                        'Reservoirs', 'TP3', 'H1']
    
    selected = df[['timestamp', 'asset_id'] + feature_cols].copy()
    logger.info(f"Selected {len(feature_cols)} features")
    return selected, feature_cols

def create_sequences(data, sequence_length=60):
    """Create sequences for LSTM"""
    X = []
    for i in range(len(data) - sequence_length):
        X.append(data[i:i+sequence_length])
    return np.array(X)

def normalize_data(df, feature_cols):
    """Normalize data using Z-score"""
    from sklearn.preprocessing import StandardScaler
    
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df[feature_cols])
    return scaled_data, scaler

def create_sequences_with_labels(data, sequence_length=60, anomaly_labels=None):
    """Create sequences with optional anomaly labels"""
    X = []
    y = []
    for i in range(len(data) - sequence_length):
        X.append(data[i:i+sequence_length])
        if anomaly_labels is not None:
            y.append(anomaly_labels[i+sequence_length])
    return np.array(X), np.array(y) if y else np.array(X)